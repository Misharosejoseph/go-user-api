package main

import "fmt"

func main() {
    fmt.Println("User API server")
}
