# User API

Run with `go run cmd/server/main.go`
